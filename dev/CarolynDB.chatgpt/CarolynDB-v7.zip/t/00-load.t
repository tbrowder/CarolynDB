
use Test;
use lib 'lib';
use CarolynDB;
use CarolynDB::DB;
use CarolynDB::Backup;
use CarolynDB::Util;

plan 5;

ok 1, 'Loaded';
my $dbfile = 'examples/sample.sqlite';
unless $dbfile.IO.e { run 'raku', 'examples/make-sample-sqlite.raku' }
ok $dbfile.IO.e, 'sample exists';

my $db = CarolynDB::DB::DB.new(:spec( CarolynDB::DB::ConnSpec.new( backend => 'sqlite', sqlite-path => $dbfile ) ));
lives-ok { $db.connect }, 'connected';

my $gb = CarolynDB::Backup::GitBackup.new(:db($db), :profile("test"));
my $id = $gb.backup;
ok $id.chars > 6, 'snapshot ok';

my $dry = $gb.restore($id, :dry);
ok $dry ~~ Hash, 'dry-run info returned';
