
unit module CarolynDB::GTKUI;
use GTK::Simple;
use CarolynDB::DB;
use CarolynDB::Backup;
use CarolynDB::Util :csv-escape, :normalize-eol, :spurt-utf8;

class App {
    has GTK::Simple::Window $.win;
    has GTK::Simple::VBox $.root;
    has GTK::Simple::HBox $.conn;
    has GTK::Simple::ComboBoxText $.backend;
    has GTK::Simple::Entry $.path;
    has GTK::Simple::Entry $.pgurl;
    has GTK::Simple::Button $.connect;
    has GTK::Simple::HBox $.controls;
    has GTK::Simple::ComboBoxText $.tables;
    has GTK::Simple::Entry $.limit;
    has GTK::Simple::Entry $.offset;
    has GTK::Simple::ComboBoxText $.sortcol;
    has GTK::Simple::ComboBoxText $.sortdir;
    has GTK::Simple::Button $.apply;
    has GTK::Simple::Button $.export;
    has GTK::Simple::Button $.backup;
    has GTK::Simple::Button $.restore;
    has GTK::Simple::Button $.theme;
    has GTK::Simple::Scrolled $.scroll;
    has GTK::Simple::VBox $.data;
    has GTK::Simple::HBox $.filters;

    has CarolynDB::DB::DB $.db is rw;
    has CarolynDB::Backup::GitBackup $.gb is rw;
    has Str $.current-table;
    has Bool $.dark = True;
    has @!columns;
    has @!rows;

    method BUILD() {
        $!win = GTK::Simple::Window.new(title => 'CarolynDB (GTK)', width => 1040, height => 760);
        self!apply-theme;

        $!root = GTK::Simple::VBox.new;

        # Connection row
        $!conn = GTK::Simple::HBox.new;
        $!backend = GTK::Simple::ComboBoxText.new; $!backend.append($_) for <sqlite postgres csv>;
        $!path = GTK::Simple::Entry.new(:placeholder-text<sqlite or csv path>);
        $!pgurl = GTK::Simple::Entry.new(:placeholder-text<postgres URL or use .pgpass>);
        $!connect = GTK::Simple::Button.new(:label<Connect>);
        $!conn.pack-start($_) for $!backend, $!path, $!pgurl, $!connect;

        # Controls
        $!controls = GTK::Simple::HBox.new;
        $!tables = GTK::Simple::ComboBoxText.new;
        $!limit = GTK::Simple::Entry.new(:text<100>);
        $!offset = GTK::Simple::Entry.new(:text<0>);
        $!sortcol = GTK::Simple::ComboBoxText.new;
        $!sortdir = GTK::Simple::ComboBoxText.new; $!sortdir.append($_) for <ASC DESC>;
        $!apply = GTK::Simple::Button.new(:label<Apply>);
        $!export  = GTK::Simple::Button.new(:label<Export CSV>);
        $!backup  = GTK::Simple::Button.new(:label<Backup>);
        $!restore = GTK::Simple::Button.new(:label<Restore…>);
        $!theme   = GTK::Simple::Button.new(:label<Toggle Theme>);
        $!controls.pack-start($_) for $!tables,
                                     GTK::Simple::Label.new(:text<Limit>), $!limit,
                                     GTK::Simple::Label.new(:text<Offset>), $!offset,
                                     GTK::Simple::Label.new(:text<Sort>), $!sortcol, $!sortdir,
                                     $!apply, $!export, $!backup, $!restore, $!theme;

        # Filters row (per-column entries)
        $!filters = GTK::Simple::HBox.new;

        # Data grid (simple rows; for very large tables, prefer web UI)
        $!data = GTK::Simple::VBox.new;
        $!scroll = GTK::Simple::Scrolled.new(:hscrollbar-policy<automatic>, :vscrollbar-policy<automatic>);
        $!scroll.add($!data);

        $!root.pack-start($_) for $!conn, $!controls, $!filters, $!scroll;
        $!win.add($!root);

        $!connect.clicked.tap({ self!on-connect });
        $!tables.changed.tap({ $!current-table = $!tables.active-text; self!reload });
        $!apply.clicked.tap({ self!reload });
        $!export.clicked.tap({ self!export-csv });
        $!backup.clicked.tap({ self!do-backup });
        $!restore.clicked.tap({ self!restore-picker });
        $!theme.clicked.tap({ $!dark = !$!dark; self!apply-theme; });
    }

    method !apply-theme() {
        my $css = $!dark ?? q:to/CSS/ !! q:to/CSS/;
window, box, button, entry, label, scrolledwindow {
  background: #121212; color: #e0e0e0; border-color: #333;
}
button { background: #1e1e1e; }
entry { background: #1a1a1a; }
CSS
window, box, button, entry, label, scrolledwindow {
  background: #fafafa; color: #222; border-color: #ddd;
}
button { background: #fff; }
entry { background: #fff; }
CSS
        GTK::Simple.apply-css($css);
    }

    method !on-connect() {
        my $backend = $!backend.active-text;
        my $path = $!path.text;
        my $url  = $!pgurl.text;
        my $spec = do given $backend {
            when 'sqlite'   { CarolynDB::DB::ConnSpec.new(:backend($backend), :sqlite-path($path)) }
            when 'postgres' { CarolynDB::DB::ConnSpec.new(:backend($backend), :url($url)) }
            default         { CarolynDB::DB::ConnSpec.new(:backend($backend), :csv-path($path)) }
        };
        $!db = CarolynDB::DB::DB.new(:spec($spec));
        try { $!db.connect } CATCH { default { say "Connect error: ", .message; return } }
        $!gb = CarolynDB::Backup::GitBackup.new(:db($!db), :profile("gtk-default"));
        $!tables.remove-all;
        for $!db.list-tables -> $t { $!tables.append($t) }
        $!current-table = $!tables.active-text;
        self!reload;
    }

    method !reload() {
        return unless $!db and $!current-table;
        my $lim = $!limit.text.Int; my $off = $!offset.text.Int;
        # Build WHERE from filter entries
        my $where = self!filters-where;
        my %res = $!db.fetch($!current-table, :limit($lim), :offset($off), :$where);
        @!columns = %res<columns>; @!rows = %res<rows>;
        # Sort client-side if requested
        if $!sortcol.active-text && @!columns.grep(* eq $!sortcol.active-text) {
            my $col = $!sortcol.active-text;
            my $dir = $!sortdir.active-text // 'ASC';
            @!rows = @!rows.sort({ .{$col} // '' }, :{$dir eq 'DESC' ?? :descending !! :ascending});
        }
        self!rebuild-filter-row;
        self!show-grid;
    }

    method !rebuild-filter-row() {
        $!filters.foreach({ $!filters.remove($_) });
        # per-column text entries
        for @!columns -> $c {
            my $e = GTK::Simple::Entry.new(:placeholder-text($c));
            $e.changed.tap({ }); # kept for potential live-filter
            $!filters.pack-start($e);
        }
        # fill sort column options
        $!sortcol.remove-all; for @!columns -> $c { $!sortcol.append($c) }
        $!win.show-all;
    }

    method !filters-where(--> Str) {
        # create SQL-like WHERE for DB backends; for CSV, DB layer ignores and uses client fetch
        # We'll read current entries in $!filters children
        my @children = $!filters.children;
        my @parts;
        for @!columns.kv -> $i, $name {
            next unless $i < @children.elems;
            my $val = @children[$i].text // '';
            next unless $val.chars;
            @parts.push("{$name} ILIKE '%{$val}%'" );
        }
        @parts.join(' AND ')
    }

    method !show-grid() {
        $!data.foreach({ $!data.remove($_) });
        # header
        my $head = GTK::Simple::HBox.new;
        for @!columns -> $c { $head.pack-start(GTK::Simple::Label.new(:text($c))) }
        $!data.pack-start($head);
        # rows
        for @!rows -> %r {
            my $row = GTK::Simple::HBox.new;
            for @!columns -> $c { $row.pack-start(GTK::Simple::Label.new(:text(%r{$c} // ''))) }
            $!data.pack-start($row);
        }
        $!win.show-all;
    }

    method !export-csv() {
        return unless $!db and $!current-table;
        my @cols = @!columns;
        my $csv = @cols.join(',') ~ "\n" ~ @!rows.map(-> %r { @cols.map({ csv-escape((%r{$_} // '').Str) }).join(',') ~ "\n" }).join;
        my $out = "export-{$!current-table.subst(/\W+/, '_', :g)}.csv";
        spurt-utf8 $out.IO, normalize-eol($csv);
        say "Exported $out";
    }

    method !do-backup() {
        return unless $!gb;
        my $id = $!gb.backup;
        say "Snapshot: $id";
    }

    method !restore-picker() {
        return unless $!gb;
        my @snaps = $!gb.list-snapshots;
        my $dialog = GTK::Simple::Window.new(title => 'Restore from snapshot', width => 640, height => 360);
        my $v = GTK::Simple::VBox.new;
        my $list = GTK::Simple::ComboBoxText.new;
        for @snaps -> %s {
            my $label = "%s<id>.substr(0,7) ~ ' — ' ~ DateTime.new(epoch => %s<time>).Str ~ ' — ' ~ %s<msg>";
            $list.append($label);
        }
        my $btn-preview = GTK::Simple::Button.new(:label<Preview>);
        my $btn-restore = GTK::Simple::Button.new(:label<Restore selected>);
        $v.pack-start($_) for $list, $btn-preview, $btn-restore;
        $dialog.add($v);
        $dialog.show-all;

        $btn-preview.clicked.tap({
            my $idx = $list.active;
            return unless $idx.defined && $idx >= 0 && $idx < @snaps.elems;
            my %sel = @snaps[$idx];
            my $dry = $!gb.restore(%sel<id>, :dry);
            my $msg = "Commit: " ~ %sel<id> ~ "\nFiles: " ~ ($dry<files> // []).join(', ');
            say $msg;
        });
        $btn-restore.clicked.tap({
            my $idx = $list.active;
            return unless $idx.defined && $idx >= 0 && $idx < @snaps.elems;
            my %sel = @snaps[$idx];
            my $ok = $!gb.restore(%sel<id>);
            say $ok ?? "Restore OK" !! "Restore FAILED";
            $dialog.close;
            self!reload if $ok;
        });
    }
}

our sub run-gtk() is export {
    my $app = App.new;
    $app.win.show-all;
    GTK::Simple.main;
}
