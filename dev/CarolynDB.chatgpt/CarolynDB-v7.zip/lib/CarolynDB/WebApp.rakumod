
unit module CarolynDB::WebApp;
use JSON::Fast;
use URI;
use Cro::HTTP::Router;
use Cro::HTTP::Server;
use CarolynDB::DB;
use CarolynDB::Schema;
use CarolynDB::Backup;
use CarolynDB::Util :csv-escape;

our sub run-app(:$host = '127.0.0.1', :$port = 3000) is export {
    my $db is rw;
    my $backup is rw;

    my $router = route {
        get -> { content 'text/html', main-page() }
        post -> 'connect' {
            my %p = request-body->body-text.&form-parse;
            try {
                my $spec = CarolynDB::DB::ConnSpec.new(
                    backend => %p<backend> // 'sqlite',
                    sqlite-path => %p<sqlite-path>,
                    url => %p<url>,
                    host => %p<host>,
                    port => (%p<port> // 5432).Int,
                    db   => %p<db>,
                    user => %p<user>,
                    pass => %p<pass>,
                    csv-path => %p<csv-path>,
                    csv-delim => %p<csv-delim> // ',',
                );
                $db = CarolynDB::DB::DB.new(:spec($spec));
                $db.connect;
                $backup = CarolynDB::Backup::GitBackup.new(:db($db), :profile("default"));
                redirect '/home';
            } CATCH { default { content 'text/html', error-page($_.message) } }
        }
        get -> 'home' {
            if !$db { redirect '/' }
            my @tables = $db.list-tables;
            content 'text/html', home-page(@tables);
        }
        get -> 'browse', *%q {
            if !$db { redirect '/' }
            my $table = %q<table>;
            my $limit = (%q<limit> // 100).Int;
            my $offset = (%q<offset> // 0).Int;
            my $where = build-where(%q);
            my %res = $db.fetch($table, :$limit, :$offset, :$where);
            content 'text/html', browse-page($table, %res<columns>, %res<rows>, $limit, $offset, %q);
        }
        get -> 'export', *%q {
            if !$db { redirect '/' }
            my $table = %q<table>;
            my $where = build-where(%q);
            my %res = $db.fetch($table, :limit(100000), :offset(0), :$where);
            my @cols = %res<columns>;
            my $head = @cols.map(&csv-escape).join(',') ~ "\n";
            my $body = %res<rows>.map(-> %r { @cols.map({ csv-escape(%r{$_} // '') }).join(',') ~ "\n" }).join;
            response.header['Content-Disposition'] = "attachment; filename={$table.subst(/\W+/, '_', :g)}.csv";
            content 'text/csv; charset=utf-8', $head ~ $body;
        }
        post -> 'backup' {
            if !$db { redirect '/' }
            my $id = $backup.backup;
            content 'text/html', info-page("Snapshot created: {$id}");
        }
        get -> 'backups' {
            if !$db { redirect '/' }
            my @snaps = $backup.list-snapshots;
            content 'text/html', backups-page(@snaps);
        }
        post -> 'restore' {
            if !$db { redirect '/' }
            my %p = request-body->body-text.&form-parse;
            my $commit = %p<commit> // '';
            my $dry = $backup.restore($commit, :dry);
            my $list = $dry ~~ Hash ?? $dry<files>.join(', ') !! 'N/A';
            # confirmation page
            content 'text/html', confirm-restore-page($commit, $list);
        }
        post -> 'restore-confirm' {
            if !$db { redirect '/' }
            my %p = request-body->body-text.&form-parse;
            my $commit = %p<commit>;
            my $ok = $backup.restore($commit);
            content 'text/html', info-page($ok ?? "Restore OK" !! "Restore FAILED");
        }
        get -> 'diagram' {
            if !$db { redirect '/' }
            my $d = CarolynDB::Schema::Diagrammer.new(:db($db));
            content 'text/html', diagram-page($d.dot);
        }
    };

    my Cro::HTTP::Server $server .= new(:$host, :$port, :application($router));
    say "CarolynDB running at http://$host:$port";
    react whenever signal(SIGINT) { $server.stop; done }
    $server.start;
    $server.supply.tap(-> $m { $m.say });
    CATCH { default { .say; exit 1 } }
}

sub form-parse(Str $s --> Hash) {
    my %out; for $s.split('&') -> $pair {
        next unless $pair.chars; my ($k,$v) = $pair.split('=', 2);
        %out{URI.unescape($k // '')} = URI.unescape($v // '');
    }; %out
}

sub build-where(%q --> Str) {
    my @parts; for 0 ..^ 6 -> $i {
        my $col = %q{"cond{$i}_col"} // ""; my $op  = %q{"cond{$i}_op"} // ""; my $val = %q{"cond{$i}_val"} // "";
        next unless $col and $op and $val;
        my $lit = $op.lc eq 'like' || $op.uc eq 'ILIKE' ?? "'%{$val}%'" !! "'{$val}'";
        @parts.push("{$col} {$op.uc} {$lit}");
        my $join = %q{"cond{$i}_join"} // ""; @parts.push($join.uc) if $join and $i < 5;
    }; @parts.join(' ')
}

# views
sub main-page(--> Str) {"<!doctype html><html><body><h1>CarolynDB</h1><p><a href='/home'>Connect first</a></p></body></html>"}
sub home-page(@tables --> Str) { "<!doctype html><html><body><h2>Tables</h2><ul>" ~ @tables.map({ "<li><a href='/browse?table={$_}'>$_</a></li>" }).join ~ "</ul><a href='/backups'>Backups</a></body></html>" }
sub browse-page($t,@c,@r,$l,$o,%q-->Str) { "<!doctype html><html><body><h2>Browse $t</h2><a href='/export?table={$t}'>Export CSV</a></body></html>" }
sub backups-page(@s-->Str) { "<!doctype html><html><body><h2>Backups</h2>" ~ @s.elems ~ " snapshots</body></html>" }
sub confirm-restore-page($commit,$files-->Str) { "<!doctype html><html><body><h2>Restore</h2><p>About to restore commit $commit</p><p>Files: $files</p><form method='POST' action='/restore-confirm'><input type='hidden' name='commit' value='$commit'><button>Confirm Restore</button></form></body></html>" }
sub diagram-page($svg-->Str) { "<!doctype html><html><body><pre>" ~ $svg.encode('xml') ~ "</pre></body></html>" }
sub info-page($m-->Str) { "<!doctype html><html><body><p>$m</p></body></html>" }
