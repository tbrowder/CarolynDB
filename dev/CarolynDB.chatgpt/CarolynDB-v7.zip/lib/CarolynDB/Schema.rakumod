
unit module CarolynDB::Schema;
use CarolynDB::DB;

class Diagrammer {
    has CarolynDB::DB::DB $.db is required;
    method dot(--> Str) {
        my @tables = $.db.list-tables;
        my $dot = "digraph schema {\n  rankdir=LR;\n  node [shape=record];\n";
        for @tables -> $t {
            my @cols = $.db.columns($t).map({ .<name> ~ (.<type> ?? " : " ~ .<type> !! "") });
            $dot ~= qq:to/END/;
  "$t" [label="{ $t | { {@cols.join(' | ')} } }"];
END
        }
        for @tables -> $t {
            my @fks = $.db.foreign-keys($t);
            for @fks -> %fk {
                if $.db.spec.backend eq 'sqlite' {
                    my $dst = %fk<table>;
                    $dot ~= qq[  "$t" -> "$dst";\n];
                } else {
                    my $dst = "%fk<dst_schema>.%fk<dst_table>";
                    $dot ~= qq[  "$t" -> "$dst";\n];
                }
            }
        }
        $dot ~= "}\n";
        $dot
    }
}
