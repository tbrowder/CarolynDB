
unit module CarolynDB::Util;

# Normalize EOLs for cross-platform CSV/text writing.
# CAROLYNDB_EOL env var: 'lf' (default), 'crlf', or 'cr'
our sub normalize-eol(Str $text --> Str) is export {
    my $mode = %*ENV<CAROLYNDB_EOL> // 'lf';
    my $lf = $text.trans("\r\n" => "\n").trans("\r" => "\n"); # normalize first
    given $mode.lc {
        when 'crlf' { $lf.trans("\n" => "\r\n") }
        when 'cr'   { $lf.trans("\n" => "\r") }
        default     { $lf } # 'lf'
    }
}

# Ensure we always write UTF-8
our sub spurt-utf8(IO::Path $path, Str $text) is export {
    $path.spurt: $text, :enc<utf8>;
}

# Simple csv escape for values (commas/quotes/newlines). RFC4180-ish
our sub csv-escape(Str $s --> Str) is export {
    my $t = $s // '';
    if $t ~~ /[\", \n, \r]/ {
        '"' ~ $t.trans('"' => '""') ~ '"'
    } else {
        $t
    }
}
