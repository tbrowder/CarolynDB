
unit module CarolynDB::DB;
use DBIish;
use CarolynDB::Util :normalize-eol, :spurt-utf8;

class ConnSpec {
    has Str $.backend is required;   # 'sqlite' | 'postgres' | 'csv'
    has Str $.sqlite-path;
    has Str $.url;
    has Str $.host;
    has Int $.port = 5432;
    has Str $.db;
    has Str $.user;
    has Str $.pass;
    has Str $.csv-path;
    has Str $.csv-delim = ',';

    method dsn(--> Str) {
        if $!backend eq 'sqlite' {
            die "sqlite-path required" unless $!sqlite-path;
            "SQLite:$!sqlite-path"
        }
        elsif $!backend eq 'postgres' {
            return "Pg:$!url" if $!url;
            my $pw = $!pass // ''; # .pgpass supported by libpq; blank uses it
            die "host, db, user required" unless $!host and $!db and $!user;
            "Pg:host={$!host};port={$!port};database={$!db};user={$!user};password={$pw}"
        }
        elsif $!backend eq 'csv' {
            die "csv-path required" unless $!csv-path;
            "CSV:{$!csv-path}"
        }
        else {
            die "Unknown backend '$!backend'"
        }
    }
}

class DB {
    has DBIish::Database $.dbh is rw;
    has ConnSpec $.spec is required;
    has @!csv-cols;
    has @!csv-rows;

    method connect() {
        if $.spec.backend eq 'csv' {
            my $p = $.spec.csv-path.IO;
            die "CSV path not found: {$p}" unless $p.e;
            my $delim = $.spec.csv-delim // ',';
            my @lines = $p.slurp(:enc<utf8>).lines;
            return if @lines.elems == 0;
            @!csv-cols = @lines.shift.split($delim);
            @!csv-rows = @lines.map({ $_.split($delim) });
            return
        }
        my $dsn = $.spec.dsn;
        $!dbh = DBIish.connect($dsn);
    }

    method list-tables(--> Seq) {
        if $.spec.backend eq 'csv' {
            <CSV>;
        }
        elsif $.spec.backend eq 'sqlite' {
            $!dbh.query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").array.map(*.hash<name>);
        }
        else {
            $!dbh.query("SELECT table_schema||'.'||table_name AS name FROM information_schema.tables WHERE table_type='BASE TABLE' AND table_schema NOT IN ('pg_catalog','information_schema') ORDER BY 1").array.map(*.hash<name>);
        }
    }

    method primary-key(Str \table --> Array) {
        if $.spec.backend eq 'sqlite' {
            my $tn = table;
            my @cols = $!dbh.query("PRAGMA table_info($tn)").array.map(*.hash);
            my @pk = @cols.grep(*.<pk> == 1).map(*.<name>);
            @pk;
        }
        elsif $.spec.backend eq 'postgres' {
            my ($schema,$name) = table.split('.', 2);
            $schema //= 'public';
            $name   //= table;
            $!dbh.query(q:to/SQL/, :schema($schema), :name($name)).array.map(*.hash<col>);
            SQL
            SELECT a.attname AS col
            FROM   pg_index i
            JOIN   pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey)
            WHERE  i.indrelid = ($1::text||'.'||$2::text)::regclass
            AND    i.indisprimary
            SQL
        }
        else {
            <row-index>  # CSV pseudo-PK
        }
    }

    method columns(Str \table --> Array) {
        if $.spec.backend eq 'csv' {
            @!csv-cols.map({ { name => $_, type => 'text' } });
        }
        elsif $.spec.backend eq 'sqlite' {
            $!dbh.query("PRAGMA table_info($table)").array.map({ .hash{name => .hash<name>, type => .hash<type>} });
        }
        else {
            my ($schema,$name) = table.split('.', 2);
            $schema //= 'public';
            $name   //= table;
            $!dbh.query(q:to/SQL/, :schema($schema), :name($name)).array.map(*.hash);
            SQL
            SELECT column_name AS name, data_type AS type
            FROM information_schema.columns
            WHERE table_schema = $1 AND table_name = $2
            ORDER BY ordinal_position
            SQL
        }
    }

    method foreign-keys(Str \table --> Array) {
        if $.spec.backend eq 'sqlite' {
            $!dbh.query("PRAGMA foreign_key_list($table)").array.map(*.hash);
        }
        elsif $.spec.backend eq 'postgres' {
            my ($schema,$name) = table.split('.', 2);
            $schema //= 'public';
            $name   //= table;
            $!dbh.query(q:to/SQL/, :schema($schema), :name($name)).array.map(*.hash);
            SQL
            SELECT
                tc.table_schema AS src_schema,
                tc.table_name   AS src_table,
                kcu.column_name AS src_col,
                ccu.table_schema AS dst_schema,
                ccu.table_name   AS dst_table,
                ccu.column_name  AS dst_col
            FROM information_schema.table_constraints AS tc
            JOIN information_schema.key_column_usage AS kcu
              ON tc.constraint_name = kcu.constraint_name AND tc.table_schema = kcu.table_schema
            JOIN information_schema.constraint_column_usage AS ccu
              ON ccu.constraint_name = tc.constraint_name AND ccu.table_schema = tc.table_schema
            WHERE tc.constraint_type = 'FOREIGN KEY'
              AND tc.table_schema = $1 AND tc.table_name = $2
            SQL
        }
        else {
            []
        }
    }

    method fetch(Str \table, Int :$limit = 100, Int :$offset = 0, Str :$where = "" --> Hash) {
        if $.spec.backend eq 'csv' {
            my @rows = @!csv-rows[$offset ..^ min($offset+$limit, +@!csv-rows)];
            my @cols = @!csv-cols;
            return { :columns(@cols), :rows(@rows.map({ my %h; for ^@cols.elems -> $i { %h{@cols[$i]} = $_[$i] // '' } %h })) };
        }
        my $sql = "SELECT * FROM $table";
        $sql ~= " WHERE $where" if $where.trim.chars;
        $sql ~= " LIMIT $limit OFFSET $offset";
        my @rows = $!dbh.query($sql).array.map(*.hash);
        my @cols = @rows.elems ?? @rows[0].keys.Array !! self.columns(table).map(*.<name>);
        { :columns(@cols), :rows(@rows) }
    }

    method run-sql(Str \sql --> Hash) {
        die "SQL disabled in CSV backend" if $.spec.backend eq 'csv';
        my $res = $!dbh.query(sql);
        my $rows = $res.array.map(*.hash);
        my $cols = $rows.elems ?? $rows[0].keys.Array !! [];
        { :columns($cols), :rows($rows) }
    }

    method fetch-row-by-pk(Str \table, *@pk-values --> Hash) {
        if $.spec.backend eq 'csv' {
            my $idx = +@pk-values == 1 ?? @pk-values[0].Int !! die "CSV edit expects single row index";
            my %h; for ^@!csv-cols.elems -> $i { %h{@!csv-cols[$i]} = @!csv-rows[$idx][$i] }
            return %h;
        }
        my @pk = self.primary-key(table);
        die "Per-row editing requires a primary key" unless @pk.elems >= 1;
        my $cond = @pk.kv.map({ @pk[$_] ~ " = ?" }).join(' AND ');
        my $sql = "SELECT * FROM $table WHERE $cond LIMIT 1";
        my $row = $!dbh.query($sql, |@pk-values).array.map(*.hash).head;
        $row // {};
    }

    method update-row-by-pk(Str \table, *@pk-values, *%sets) {
        if $.spec.backend eq 'csv' {
            my $idx = @pk-values[0].Int;
            for ^@!csv-cols.elems -> $i { 
                my $col = @!csv-cols[$i];
                @!csv-rows[$idx][$i] = %sets{$col} if %sets{$col}:exists;
            }
            self.csv-save;
            return True
        }
        my @pk = self.primary-key(table);
        die "Per-row editing requires a primary key" unless @pk.elems >= 1;
        die "No columns to update" unless %sets.keys.elems;
        my $set = %sets.keys.map({ "$_ = ?" }).join(', ');
        my $cond = @pk.kv.map({ @pk[$_] ~ " = ?" }).join(' AND ');
        my @vals = %sets.values, |@pk-values;
        my $sql = "UPDATE $table SET $set WHERE $cond";
        $!dbh.query($sql, |@vals);
        True
    }

    method csv-save() {
        my $delim = $.spec.csv-delim // ',';
        my $out = $.spec.csv-path.IO;
        my $text = @!csv-cols.join($delim) ~ "\n" ~ @!csv-rows.map({ .join($delim) }).join("\n") ~ "\n";
        spurt-utf8 $out, normalize-eol($text);
    }
}
