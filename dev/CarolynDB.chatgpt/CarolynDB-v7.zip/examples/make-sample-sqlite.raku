#!/usr/bin/env raku
use DBIish;
my $p = $*PROGRAM.parent.add('sample.sqlite').Str;
unlink $p if $p.IO.e;
my $dbh = DBIish.connect("SQLite:$p");
$dbh.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, name TEXT)");
$dbh.execute("INSERT INTO t (name) VALUES ('αβγ'), ('漢字'), ('emoji 😀')");
say "Created $p";
