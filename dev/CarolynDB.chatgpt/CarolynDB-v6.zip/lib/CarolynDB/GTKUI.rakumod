
unit module CarolynDB::GTKUI;

use GTK::Simple;
use GTK::Simple::CSS;
use CarolynDB::DB;
use CarolynDB::Backup;

class App {
    has GTK::Simple::Window $.win;
    has GTK::Simple::VBox $.root;
    has GTK::Simple::HBox $.conn;
    has GTK::Simple::ComboBoxText $.backend;
    has GTK::Simple::Entry $.path;
    has GTK::Simple::Entry $.pgurl;
    has GTK::Simple::Button $.connect;
    has GTK::Simple::HBox $.controls;
    has GTK::Simple::Entry $.limit;
    has GTK::Simple::Entry $.offset;
    has GTK::Simple::Button $.refresh;
    has GTK::Simple::Button $.export;
    has GTK::Simple::Button $.backup;
    has GTK::Simple::Button $.restore;
    has GTK::Simple::Scrolled $.scroll;
    has GTK::Simple::VBox $.data;
    has GTK::Simple::ComboBoxText $.tables;

    has GTK::Simple::CSS $.css;

    has CarolynDB::DB::DB $.db is rw;
    has CarolynDB::Backup::GitBackup $.gb is rw;
    has Str $.current-table;

    method BUILD() {
        $!win = GTK::Simple::Window.new(title => 'CarolynDB (GTK)', width => 980, height => 720);
        self!apply-dark;

        $!root = GTK::Simple::VBox.new;
        $!conn = GTK::Simple::HBox.new;
        $!backend = GTK::Simple::ComboBoxText.new;
        $!backend.append('sqlite'); $!backend.append('postgres'); $!backend.append('csv');
        $!path = GTK::Simple::Entry.new(:placeholder-text<sqlite/csv path>);
        $!pgurl = GTK::Simple::Entry.new(:placeholder-text<postgres URL or leave blank and use .pgpass>);
        $!connect = GTK::Simple::Button.new(:label<Connect>);
        $!conn.pack-start($_) for $!backend, $!path, $!pgurl, $!connect;

        $!controls = GTK::Simple::HBox.new;
        $!tables = GTK::Simple::ComboBoxText.new;
        $!limit = GTK::Simple::Entry.new(:text<100>);
        $!offset = GTK::Simple::Entry.new(:text<0>);
        $!refresh = GTK::Simple::Button.new(:label<Reload>);
        $!export  = GTK::Simple::Button.new(:label<Export CSV>);
        $!backup  = GTK::Simple::Button.new(:label<Backup>);
        $!restore = GTK::Simple::Button.new(:label<Restore…>);
        $!controls.pack-start($_) for $!tables, GTK::Simple::Label.new(:text<Limit>), $!limit,
                                     GTK::Simple::Label.new(:text<Offset>), $!offset,
                                     $!refresh, $!export, $!backup, $!restore;

        $!data = GTK::Simple::VBox.new;
        $!scroll = GTK::Simple::Scrolled.new(:hscrollbar-policy<automatic>, :vscrollbar-policy<automatic>);
        $!scroll.add($!data);

        $!root.pack-start($_) for $!conn, $!controls, $!scroll;
        $!win.add($!root);

        $!connect.clicked.tap({ self!on-connect });
        $!refresh.clicked.tap({ self!reload });
        $!export.clicked.tap({ self!export-csv });
        $!backup.clicked.tap({ self!do-backup });
        $!restore.clicked.tap({ self!restore-picker });
        $!tables.changed.tap({ $!current-table = $!tables.active-text; self!reload });
    }

    method !apply-dark() {
        # App-scoped dark palette via CSS (does not change system settings)
        my $css = q:to/CSS/;
        * { color: #e6e6e6; }
        window, box, scrolledwindow { background: #1f1f1f; }
        entry, combobox, button { background: #2a2a2a; color: #e6e6e6; border: 1px solid #3a3a3a; }
        label { color: #e6e6e6; }
        CSS
        $!css = GTK::Simple::CSS.new;
        $!css.load($css);
        $!css.bind($!win);
    }

    method !on-connect() {
        my $backend = $!backend.active-text;
        my $path = $!path.text;
        my $url  = $!pgurl.text;
        my $spec = do given $backend {
            when 'sqlite'   { CarolynDB::DB::ConnSpec.new(:backend($backend), :sqlite-path($path)) }
            when 'postgres' { CarolynDB::DB::ConnSpec.new(:backend($backend), :url($url)) }
            default         { CarolynDB::DB::ConnSpec.new(:backend($backend), :csv-path($path)) }
        };
        $!db = CarolynDB::DB::DB.new(:spec($spec));
        try { $!db.connect } CATCH { default { say "Connect error: ", .message; return } }
        $!gb = CarolynDB::Backup::GitBackup.new(:db($!db), :profile("gtk-default"));
        $!tables.remove-all;
        for $!db.list-tables -> $t { $!tables.append($t) }
        $!current-table = $!tables.active-text;
        self!reload;
    }

    method !reload() {
        return unless $!db and $!current-table;
        my $lim = $!limit.text.Int;
        my $off = $!offset.text.Int;
        my %res = $!db.fetch($!current-table, :limit($lim), :offset($off));
        self!show-grid(%res<columns>, %res<rows>);
    }

    method !show-grid(@cols, @rows) {
        $!data.foreach({ $!data.remove($_) });
        my $head = GTK::Simple::HBox.new;
        for @cols -> $c { $head.pack-start(GTK::Simple::Label.new(:text($c))) }
        $!data.pack-start($head);
        for @rows -> %r {
            my $row = GTK::Simple::HBox.new;
            for @cols -> $c { $row.pack-start(GTK::Simple::Label.new(:text(%r{$c} // ''))) }
            $!data.pack-start($row);
        }
        $!win.show-all;
    }

    method !export-csv() {
        return unless $!db and $!current-table;
        my %res = $!db.fetch($!current-table, :limit(100000), :offset(0));
        my @cols = %res<columns>;
        my $csv = @cols.join(',') ~ "\n" ~ %res<rows>.map(-> %r { @cols.map({ (%r{$_} // '').trans([',', "\n"] => [';', ' ']) }).join(',') ~ "\n" }).join;
        my $out = "export-{$!current-table.subst(/\W+/, '_', :g)}.csv";
        spurt $out, $csv;
        say "Exported $out";
    }

    method !do-backup() {
        return unless $!gb;
        my $id = $!gb.backup;
        say "Snapshot: $id";
    }

    method !restore-picker() {
        return unless $!gb;
        my @snaps = $!gb.list-snapshots(:max(100));
        if @snaps.elems == 0 {
            say "No snapshots to restore."; return
        }
        # Build a simple picker window
        my $w = GTK::Simple::Window.new(title => 'Restore Snapshot', width => 520, height => 200);
        $!css.bind($w);  # apply dark CSS to dialog too
        my $v = GTK::Simple::VBox.new;
        my $combo = GTK::Simple::ComboBoxText.new;
        for @snaps -> %s {
            my $label = "{%s<id>.substr(0,7)} — " ~ DateTime.new(:epoch(%s<time>)).Str ~ " — {%s<msg> // ''}";
            $combo.append($label);
        }
        $combo.set-active(0);
        my $btn = GTK::Simple::Button.new(:label<Restore selected>);
        $btn.clicked.tap({
            my $idx = $combo.active;
            my $id  = @snaps[$idx]<id>;
            my $ok = $!gb.restore($id);
            say $ok ?? "Restore OK ($id)" !! "Restore FAILED ($id)";
            self!reload if $ok;
            $w.destroy;
        });
        $v.pack-start($_) for GTK::Simple::Label.new(:text<Choose a snapshot to restore:>), $combo, $btn;
        $w.add($v);
        $w.show-all;
    }
}

our sub run-gtk() is export {
    my $app = App.new;
    $app.win.show-all;
    GTK::Simple.main;
}
