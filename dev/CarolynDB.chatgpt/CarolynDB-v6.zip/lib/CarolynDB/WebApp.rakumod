
unit module CarolynDB::WebApp;

use JSON::Fast;
use URI;
use Cro::HTTP::Router;
use Cro::HTTP::Server;
use CarolynDB::DB;
use CarolynDB::Schema;
use CarolynDB::Backup;

our sub run-app(:$host = '127.0.0.1', :$port = 3000) is export {
    my $db is rw;
    my $backup is rw;

    my $router = route {
        get -> { content 'text/html', main-page(); }

        post -> 'connect' {
            my %p = request-body->body-text.&form-parse;
            try {
                my $spec = CarolynDB::DB::ConnSpec.new(
                    backend => %p<backend> // 'sqlite',
                    sqlite-path => %p<sqlite-path>,
                    url => %p<url>,
                    host => %p<host>,
                    port => (%p<port> // 5432).Int,
                    db   => %p<db>,
                    user => %p<user>,
                    pass => %p<pass>,
                    csv-path => %p<csv-path>,
                    csv-delim => %p<csv-delim> // ',',
                );
                $db = CarolynDB::DB::DB.new(:spec($spec));
                $db.connect;
                $backup = CarolynDB::Backup::GitBackup.new(:db($db), :profile("default"));
                redirect '/home';
            }
            CATCH { default { content 'text/html', error-page($_.message) } }
        }

        get -> 'home' {
            if !$db { redirect '/' }
            my @tables = $db.list-tables;
            content 'text/html', home-page(@tables);
        }

        get -> 'browse', *%q {
            if !$db { redirect '/' }
            my $table = %q<table>;
            my $limit = (%q<limit> // 100).Int;
            my $offset = (%q<offset> // 0).Int;
            my $where = build-where(%q);
            my %res = $db.fetch($table, :$limit, :$offset, :$where);
            content 'text/html', browse-page($table, %res<columns>, %res<rows>, $limit, $offset, %q);
        }

        get -> 'export', *%q {
            if !$db { redirect '/' }
            my $table = %q<table>;
            my $where = build-where(%q);
            my %res = $db.fetch($table, :limit(100000), :offset(0), :$where);
            my $csv = to-csv(%res<columns>, %res<rows>);
            response.header['Content-Disposition'] = "attachment; filename={$table.subst(/\W+/, '_', :g)}.csv";
            content 'text/csv', $csv;
        }

        post -> 'backup' {
            if !$db { redirect '/' }
            my $id = $backup.backup;
            content 'text/html', info-page("Snapshot created: {$id}");
        }

        get -> 'backups' {
            if !$db { redirect '/' }
            my @snaps = $backup.list-snapshots;
            content 'text/html', backups-page(@snaps);
        }

        post -> 'restore' {
            if !$db { redirect '/' }
            my %p = request-body->body-text.&form-parse;
            my $commit = %p<commit> // '';
            my $ok = $backup.restore($commit);
            content 'text/html', info-page($ok ?? "Restore OK" !! "Restore FAILED");
        }

        get -> 'sql' { if !$db or $db.spec.backend eq 'csv' { redirect '/home' } content 'text/html', sql-page("") }
        post -> 'sql' {
            if !$db or $db.spec.backend eq 'csv' { redirect '/home' }
            my %p = request-body->body-text.&form-parse;
            my $sql = %p<sql> // "";
            my %res = $db.run-sql($sql);
            content 'text/html', sql-page($sql, %res<columns>, %res<rows>);
        }

        get -> 'diagram' {
            if !$db { redirect '/' }
            my $d = CarolynDB::Schema::Diagrammer.new(:db($db));
            my $svg-path = "schema.svg";
            my $ok = True;
            try { $d.render-svg(:out($svg-path)); CATCH { default { $ok = False } } }
            if $ok && $svg-path.IO.e { content 'text/html', diagram-page(slurp $svg-path) }
            else { content 'text/html', diagram-page("<pre>" ~ $d.dot.encode('xml') ~ "</pre>") }
        }
    };

    my Cro::HTTP::Server $server .= new(:$host, :$port, :application($router));
    say "CarolynDB running at http://$host:$port";
    react whenever signal(SIGINT) { $server.stop; done }
    $server.start;
    $server.supply.tap(-> $m { $m.say });
    CATCH { default { .say; exit 1 } }
}

# Helpers / views

sub form-parse(Str $s --> Hash) {
    my %out; for $s.split('&') -> $pair {
        next unless $pair.chars;
        my ($k,$v) = $pair.split('=', 2);
        %out{URI.unescape($k // '')} = URI.unescape($v // '');
    }; %out
}

sub build-where(%q --> Str) {
    my @parts; for 0 ..^ 6 -> $i {
        my $col = %q{"cond{$i}_col"} // "";
        my $op  = %q{"cond{$i}_op"}  // "";
        my $val = %q{"cond{$i}_val"} // "";
        next unless $col and $op and $val;
        my $lit = $op.lc eq 'like' || $op.uc eq 'ILIKE' ?? "'%{$val}%'" !! "'{$val}'";
        @parts.push("{$col} {$op.uc} {$lit}");
        my $join = %q{"cond{$i}_join"} // "";
        @parts.push($join.uc) if $join and $i < 5;
    }; @parts.join(' ')
}

sub to-csv(@cols, @rows --> Str) {
    my $head = @cols.join(',') ~ "\n";
    my $body = @rows.map(-> %r { @cols.map({ (%r{$_} // '').trans([',', "\n"] => [';', ' ']) }).join(',') ~ "\n" }).join;
    $head ~ $body
}

sub main-page(--> Str) {
    qq:to/HTML/;
<!doctype html>
<html><head><meta charset="utf-8"><title>CarolynDB</title>
<style>
body { font-family: system-ui, sans-serif; max-width: 1000px; margin: 2rem auto; }
.card { border: 1px solid #ddd; padding: 1rem; border-radius: 8px; }
label { display: block; margin-top: .4rem; }
</style>
</head><body>
<h1>CarolynDB</h1>
<form method="POST" action="/connect" class="card">
<label>Backend
<select name="backend">
<option value="sqlite">SQLite</option>
<option value="postgres">PostgreSQL</option>
<option value="csv">CSV/Text</option>
</select>
</label>
<div>
<label>SQLite file <input name="sqlite-path" placeholder="/path/to/file.sqlite"></label>
</div>
<div>
<label>CSV file <input name="csv-path" placeholder="/path/to/data.csv"></label>
<label>Delimiter <input name="csv-delim" value="," size="4"></label>
</div>
<hr/>
<div>
<label>Postgres URL (optional) <input name="url" placeholder="postgres://user:pass@host:5432/dbname"></label>
</div>
<div style="display:flex;gap:8px;flex-wrap:wrap">
<label>Host <input name="host" placeholder="localhost"></label>
<label>Port <input name="port" value="5432"></label>
<label>DB <input name="db"></label>
<label>User <input name="user"></label>
<label>Pass <input type="password" name="pass"></label>
</div>
<p><button type="submit">Connect</button></p>
</form>
</body></html>
HTML
}

sub home-page(@tables --> Str) {
    my $list = @tables.map({ "<li><a href=\"/browse?table={$_}&limit=100&offset=0\">{$_}</a></li>" }).join("\n");
    qq:to/HTML/;
<!doctype html>
<html><head><meta charset="utf-8"><title>Tables</title></head>
<body>
<h2>Tables</h2>
<ul>
$list
</ul>
<p>
<a href="/sql">SQL</a> |
<a href="/diagram">Schema Diagram</a> |
<a href="/backups">Backups</a>
</p>
</body></html>
HTML
}

sub browse-page($table, @columns, @rows, $limit, $offset, %q --> Str) {
    my $thead = @columns.map({ "<th>{.}</th>" }).join;
    my $rows  = @rows.map(-> %r { "<tr>" ~ @columns.map({ "<td>{ %r{$_} // '' }</td>" }).join ~ "</tr>" }).join("\n");

    my $builder = q:to/HTML/;
<fieldset>
<legend>Filter builder</legend>
<div style="display:grid;grid-template-columns: 1fr 120px 1fr 70px;gap:.25rem;align-items:center">
HTML
    for 0 .. 5 -> $i {
        $builder ~= qq:to/HTML/;
<select name="cond{$i}_col"><option></option>{@columns.map({ "<option>{$_}</option>" }).join('')}</select>
<select name="cond{$i}_op">
  <option></option><option>=</option><option>!=</option><option>&lt;</option><option>&gt;</option>
  <option>LIKE</option><option>ILIKE</option>
</select>
<input name="cond{$i}_val" placeholder="value">
<select name="cond{$i}_join"><option></option><option>AND</option><option>OR</option></select>
HTML
    }
    $builder ~= "</div></fieldset>";

    qq:to/HTML/;
<!doctype html>
<html><head><meta charset="utf-8"><title>Browse { $table }</title>
<style>table{border-collapse:collapse}td,th{border:1px solid #ddd;padding:.3rem .5rem}</style>
</head><body>
<h2>Browse: { $table }</h2>
<form method="GET" action="/browse">
<input type="hidden" name="table" value="{ $table }">
<label>Limit <input name="limit" value="{ %q<limit> // $limit }" size="6"></label>
<label>Offset <input name="offset" value="{ %q<offset> // $offset }" size="6"></label>
$builder
<p>
<button type="submit">Apply</button>
<a href="/export?table={$table}">Export CSV</a>
</p>
</form>
<table>
<thead><tr>$thead</tr></thead>
<tbody>
$rows
</tbody>
</table>
<p><a href="/home">◀ Tables</a></p>
<form method="POST" action="/backup"><button>Backup (git)</button></form>
</body></html>
HTML
}

sub sql-page($sql, @columns = [], @rows = [] --> Str) {
    my $thead = @columns.map({ "<th>{$_}</th>" }).join;
    my $rows  = @rows.map(-> %r { "<tr>" ~ @columns.map({ "<td>{ %r{$_} // '' }</td>" }).join ~ "</tr>" }).join;
    qq:to/HTML/;
<!doctype html>
<html><head><meta charset="utf-8"><title>SQL</title>
<style>table{border-collapse:collapse}td,th{border:1px solid #ddd;padding:.3rem .5rem}</style>
</head><body>
<h2>SQL</h2>
<form method="POST" action="/sql">
<textarea name="sql" style="width:100%;height:180px">{ $sql }</textarea>
<p><button type="submit">Run</button> <a href="/home">Tables</a></p>
</form>
<table>
<thead><tr>$thead</tr></thead>
<tbody>$rows</tbody>
</table>
</body></html>
HTML
}

sub backups-page(@snaps --> Str) {
    my $rows = @snaps.map({
        my $dt = DateTime.new(epoch => .<time>).Str;
        qq[<tr><td>{.<id>.substr(0,7)}</td><td>{$dt}</td><td>{.<msg>}</td>
        <td><form method="POST" action="/restore"><input type="hidden" name="commit" value="{.<id>}"><button>Restore</button></form></td></tr>]
    }).join("\n");
    qq:to/HTML/;
<!doctype html><html><head><meta charset="utf-8"><title>Backups</title>
<style>table{border-collapse:collapse}td,th{border:1px solid #ddd;padding:.3rem .5rem}</style>
</head><body>
<h2>Backups</h2>
<table><thead><tr><th>Commit</th><th>Time</th><th>Message</th><th>Actions</th></tr></thead><tbody>
$rows
</tbody></table>
<p><a href="/home">◀ Back</a></p>
</body></html>
HTML
}

sub diagram-page($svg --> Str) {
    qq:to/HTML/;
<!doctype html><html><head><meta charset="utf-8"><title>Diagram</title></head>
<body>
<h2>Schema Diagram</h2>
<div>$svg</div>
<p><a href="/home">◀ Back</a></p>
</body></html>
HTML
}

sub info-page($msg --> Str) {
    qq:to/HTML/;
<!doctype html><html><head><meta charset="utf-8"><title>Info</title></head>
<body>
<h2>Info</h2>
<p>{$msg.encode('xml')}</p>
<p><a href="/home">◀ Back</a></p>
</body></html>
HTML
}
