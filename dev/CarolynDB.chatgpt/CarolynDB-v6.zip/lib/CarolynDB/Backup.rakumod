
unit module CarolynDB::Backup;

use JSON::Fast;
use CarolynDB::DB;

class GitBackup {
    has Str $.dir = %*ENV<CAROLYNDB_BACKUP_DIR> // 'backups';
    has CarolynDB::DB::DB $.db is required;
    has Str $.profile = 'default';  # subdir to separate different connections

    method !repo-cmd(*@args --> Proc) {
        my $cmd = "git -C {$!dir} " ~ @args.join(' ');
        run 'sh', '-c', $cmd, :out, :err
    }

    method ensure-repo() {
        mkdir $!dir unless $!dir.IO.d;
        self.!repo-cmd('init') if not $!dir.add('.git').IO.d;
    }

    method profile-path(--> IO::Path) {
        my $p = $!dir.IO.add($.profile);
        mkdir $p unless $p.d;
        $p
    }

    method backup(--> Str) {
        self.ensure-repo;
        my $p = self.profile-path;

        spurt $p.add('meta.json'), to-json { backend => $.db.spec.backend, when => DateTime.now.Str };

        if $.db.spec.backend eq 'sqlite' {
            my $src = $.db.spec.sqlite-path.IO;
            my $dst = $p.add('sqlite_file.sqlite');
            $src.copy($dst) if $src.e;
            my $dump = $p.add('sqlite_dump.sql');
            run 'sh', '-c', "sqlite3 {$src} .dump > {$dump}" if $src.e;
        }
        elsif $.db.spec.backend eq 'postgres' {
            my $dump = $p.add('pg_dump.sql');
            my $url = $.db.spec.url // "postgres://{$.db.spec.user}:{$.db.spec.pass // ''}@{$.db.spec.host}:{$.db.spec.port}/{$.db.spec.db}";
            run 'sh', '-c', "pg_dump \"{$url}\" > {$dump}";
        }
        else {
            my $csv = $p.add('data.csv');
            my $src = $.db.spec.csv-path.IO;
            $src.copy($csv) if $src.e;
        }

        self.!repo-cmd('add .');
        self.!repo-cmd('commit -m "snapshot ' + DateTime.now.Str + '"');
        my $proc = self.!repo-cmd('rev-parse HEAD');
        my $out = $proc.out.slurp.decode('utf8').trim;
        $out.chars ?? $out !! 'unknown'
    }

    method list-snapshots(Int :$max = 50 --> Array) {
        self.ensure-repo;
        my $proc = self.!repo-cmd("log --pretty=format:'%H::%ct::%s' -n {$max}");
        my @lines = $proc.out.slurp.decode('utf8').lines;
        @lines.map({
            my ($h,$ct,$s) = .split('::', 3);
            { id => $h, time => $ct.Int, msg => $s // '' }
        });
    }

    method restore(Str \commit --> Bool) {
        self.ensure-repo;
        my $p = self.profile-path;
        my $tmp = $*TMPDIR.add("carolyndb-restore").IO; mkdir $tmp unless $tmp.d;
        my $pr = run 'sh', '-c', "git -C {$!dir} archive {commit} {$.profile} | tar -x -C {$tmp}", :out, :err;
        die "Unable to read snapshot {commit}" if $pr.exitcode != 0;
        my $snap = $tmp.add($.profile);

        if $.db.spec.backend eq 'sqlite' {
            my $file = $snap.add('sqlite_file.sqlite');
            my $dump = $snap.add('sqlite_dump.sql');
            if $file.e { $file.copy($.db.spec.sqlite-path.IO); return True }
            elsif $dump.e {
                my $target = $.db.spec.sqlite-path.IO;
                unlink $target if $target.e;
                my $proc = run 'sh', '-c', "sqlite3 {$target} < {$dump}", :out, :err;
                return $proc.exitcode == 0
            }
            else { die "No sqlite snapshot found" }
        }
        elsif $.db.spec.backend eq 'postgres' {
            my $dump = $snap.add('pg_dump.sql');
            die "No pg_dump.sql in snapshot" unless $dump.e;
            my $url = $.db.spec.url // "postgres://{$.db.spec.user}:{$.db.spec.pass // ''}@{$.db.spec.host}:{$.db.spec.port}/{$.db.spec.db}";
            my $proc = run 'sh', '-c', "psql \"{$url}\" < {$dump}", :out, :err;
            return $proc.exitcode == 0
        }
        else {
            my $csv = $snap.add('data.csv');
            die "No CSV in snapshot" unless $csv.e;
            $csv.copy($.db.spec.csv-path.IO);
            True
        }
    }
}
