#!/usr/bin/env raku
use DBIish;
my $path = $*PROGRAM.parent.add('sample.sqlite').Str;
unlink $path if $path.IO.e;
my $dbh = DBIish.connect("SQLite:$path");
$dbh.execute("PRAGMA foreign_keys = ON");
$dbh.execute(q:to/SQL/);
CREATE TABLE authors (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL
);
SQL
$dbh.execute(q:to/SQL/);
CREATE TABLE editions (
  id INTEGER,
  edition INTEGER,
  title TEXT NOT NULL,
  PRIMARY KEY (id, edition)
);
SQL
$dbh.execute("INSERT INTO authors (name) VALUES ('Jane Doe'), ('John Roe')");
$dbh.execute("INSERT INTO editions (id, edition, title) VALUES (1,1,'Hello Raku'),(1,2,'Hello Raku, 2e'),(2,1,'DB Fun')");
say "Created $path";
