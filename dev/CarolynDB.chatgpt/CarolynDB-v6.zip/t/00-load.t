
use Test;
use lib 'lib';
use CarolynDB;
use CarolynDB::DB;
use CarolynDB::Schema;
use CarolynDB::Backup;

plan 5;

ok 1, 'Loaded CarolynDB';

my $dbfile = 'examples/sample.sqlite';
if !$dbfile.IO.e {
    run 'raku', 'examples/make-sample-sqlite.raku';
}
ok $dbfile.IO.e, 'sample sqlite created';

my $spec = CarolynDB::DB::ConnSpec.new( backend => 'sqlite', sqlite-path => $dbfile );
my $db   = CarolynDB::DB::DB.new(:spec($spec));
lives-ok { $db.connect }, 'connected to sqlite';

my @tables = $db.list-tables;
ok @tables.grep(* eq 'authors') && @tables.grep(* eq 'editions'), 'tables present';

my $gb = CarolynDB::Backup::GitBackup.new(:db($db), :profile("test"));
ok $gb.list-snapshots ~~ Array, 'backup interface available';
