Sample project bundle contents.
